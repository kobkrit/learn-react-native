//TODO: Uncomment on which component you like to see.
// import a from './renderJSX.js';
// import a from './basicElement.js';
// import a from './flexDirection.js';
// import a from './flexAttributeWithBox.js';
// import a from './justifyContent.js';
// import a from './alignItems.js';
// import a from './flexWrap.js';
// import a from './alignSelf.js';
// import a from './basicCSS.js';
// import a from './exercise1.js';
// import a from './exercise2.js';
// import a from './exercise3.js';
// import a from './exercise4.js';
// import a from './text.js';
import a from './moreCSS.js';
